﻿$ErrorActionPreference = 'Stop'
$appcmd = Join-Path $env:windir 'System32\inetsrv\appcmd.exe'
if (-not (Test-Path -LiteralPath $appcmd)) { exit 0 }
if (-not (Get-Service -Name FTPSVC -ErrorAction SilentlyContinue)) { exit 0 }
& $appcmd set config -section:system.applicationHost/sites '/siteDefaults.ftpServer.security.authentication.anonymousAuthentication.enabled:False' /commit:apphost
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
$siteNames = @(& $appcmd list sites /text:name)
foreach ($siteName in $siteNames) {
    if ([string]::IsNullOrWhiteSpace($siteName)) { continue }
    $escapedName = $siteName.Replace("'", "''")
    & $appcmd set config -section:system.applicationHost/sites "/[name='$escapedName'].ftpServer.security.authentication.anonymousAuthentication.enabled:False" /commit:apphost
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}
