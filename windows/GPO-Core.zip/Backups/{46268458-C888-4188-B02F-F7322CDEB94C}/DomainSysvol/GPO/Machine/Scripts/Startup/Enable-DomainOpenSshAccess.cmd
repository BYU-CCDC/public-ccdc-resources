@echo off
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "\\c22.cloner.local\SYSVOL\c22.cloner.local\Policies\{99d88586-5064-40f9-860c-a1519831ed88}\Machine\Scripts\Startup\Enable-DomainOpenSshAccess.ps1"
exit /b %errorlevel%
