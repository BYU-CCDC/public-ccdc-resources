﻿$ErrorActionPreference = 'Stop'
$sshService = Get-Service -Name sshd -ErrorAction SilentlyContinue
if (-not $sshService) { exit 0 }
$sshServiceDetails = Get-CimInstance -ClassName Win32_Service -Filter "Name='sshd'" -ErrorAction Stop
$sshdPath = [regex]::Match([string]$sshServiceDetails.PathName, '^\s*"?(.+?\.exe)"?(?:\s|$)', [System.Text.RegularExpressions.RegexOptions]::IgnoreCase).Groups[1].Value
if (-not (Test-Path -LiteralPath $sshdPath)) {
    $sshdPath = @(
        (Join-Path $env:windir 'System32\OpenSSH\sshd.exe')
        (Join-Path $env:ProgramFiles 'OpenSSH\sshd.exe')
    ) | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
}
if (-not $sshdPath) { throw 'Could not find the OpenSSH server executable to validate sshd_config.' }
$configPath = Join-Path $env:ProgramData 'ssh\sshd_config'
if (-not (Test-Path -LiteralPath $configPath)) { exit 0 }
$lines = @(Get-Content -LiteralPath $configPath)
$filtered = @($lines | Where-Object { $_ -notmatch '^\s*(AllowGroups|AllowUsers|DenyGroups|DenyUsers)\b' })
if ($filtered.Count -eq $lines.Count) { exit 0 }
$backupPath = "$configPath.ccdc.bak"
if (-not (Test-Path -LiteralPath $backupPath)) {
    Copy-Item -LiteralPath $configPath -Destination $backupPath -ErrorAction Stop
}
$utf8 = [System.Text.UTF8Encoding]::new($false)
[System.IO.File]::WriteAllLines($configPath, [string[]]$filtered, $utf8)
$validationOutput = & $sshdPath -t -f $configPath 2>&1
$validationExitCode = $LASTEXITCODE
if ($validationExitCode -ne 0) {
    [System.IO.File]::WriteAllLines($configPath, [string[]]$lines, $utf8)
    throw "OpenSSH rejected the unrestricted Domain Users access configuration (exit $validationExitCode): $($validationOutput -join ' ')"
}
if ($sshService.Status -eq 'Running') { Restart-Service -Name sshd -ErrorAction Stop }
else { Start-Service -Name sshd -ErrorAction Stop }
